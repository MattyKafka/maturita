package com.example.timer;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.util.Duration;


public class LoginController {

    @FXML
    public Button closeButton;

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label errorLabel;

    @FXML
    private void handleLoginButton(ActionEvent event) {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (username.equals("matej") && password.equals("admin")) {
            System.out.println("Přihlášení úspěšné");
            // Login se povedl - zavře se okno a pustí nás do aplikace
            ((Stage) usernameField.getScene().getWindow()).close();
        } else {
            // Login se nepovedl - error
            errorLabel.setText("Invalid username or password");
            System.out.println("Přihlášení se nezdařilo");
        }
    }
}