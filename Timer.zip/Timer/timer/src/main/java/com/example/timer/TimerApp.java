package com.example.timer;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class TimerApp extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Loadnutí Login.fxml a loginStage
        FXMLLoader loginLoader = new FXMLLoader(getClass().getResource("Login.fxml"));
        Parent loginRoot = loginLoader.load();
        Stage loginStage = new Stage();
        loginStage.setTitle("Login");
        loginStage.setScene(new Scene(loginRoot));

        // nastavení controlleru pro Login.fxml
        LoginController loginController = loginLoader.getController();
        loginStage.setOnCloseRequest(event -> System.exit(0)); // pokud se nelogneme a zavřeme login okno - celá app zemře

        // zobrazení login stage a čekání na uzavření
        loginStage.showAndWait();


        // loadnutí fxml filu a nastavení BorderPane jako root
        FXMLLoader loader = new FXMLLoader(getClass().getResource("swag.fxml"));
        System.out.println("Aplikace běží");
        BorderPane root = loader.load();

        // nastevení titlu a scény
        primaryStage.setTitle("Giga Láčes Časovač");
        primaryStage.setScene(new Scene(root));

        // nastavení controleru
        TimerController controller = loader.getController();
        controller.setStage(primaryStage);

        // zobrazení
        primaryStage.initStyle(StageStyle.UNDECORATED);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
